#!/usr/bin/env bash

hugepages -r