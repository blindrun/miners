#!/usr/bin/env bash

/home/user/RainbowMiner/start.sh